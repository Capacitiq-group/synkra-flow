import { createAction, Property } from '@activepieces/pieces-framework';
import { Client } from '@notionhq/client';
import { notionAuth } from '../auth';
import { getNotionToken, notionCommon } from '../common';
import { addCommentActionOutputSchema } from '../output-schemas';

export const addComment = createAction({
  auth: notionAuth,
  name: 'add_comment',
  classification: 'WRITE',
  displayName: 'Add Comment',
  description: 'Add a comment to a page.',
  audience: 'human',
  aiMetadata: {
    description:
      'Posts a new comment thread on a Notion page. Use when an agent must leave feedback or a note on a page for collaborators; requires the page id and comment text, and the integration must have comment-insert capability. Not idempotent: each call posts a separate comment.',
    idempotent: false,
  },
  props: {
    page_id: notionCommon.page,
    comment_text: Property.LongText({
      displayName: 'Comment Text',
      description: 'Posted as a new comment thread on the page.',
      required: true,
    }),
  },
  outputSchema: addCommentActionOutputSchema,
  async run(context) {
    const { page_id, comment_text } = context.propsValue;

    if (!comment_text) {
      throw new Error('Comment text is required');
    }

    const notion = new Client({
      auth: getNotionToken(context.auth),
      notionVersion: '2022-02-22',
    });

    const commentData: any = {
      rich_text: [
        {
          text: {
            content: comment_text,
          },
        },
      ],
    };

    if (!page_id) {
      throw new Error('Page ID is required');
    }

    commentData.parent = {
      page_id: page_id,
    };

    try {
      const response = await notion.comments.create(commentData);
      if (response.object === 'comment' && Object.keys(response).length <= 2) {
        return {
          success: true,
          message:
            '💬 Comment posted successfully! Your comment has been added to the page.',
          comment_id: response.id,
          note: 'Limited comment details available. To see full comment content, ensure your Notion integration has "Read comments" capability enabled in your workspace settings.',
        };
      }

      return {
        success: true,
        message:
          '💬 Comment posted successfully! Your comment has been added to the page.',
        comment: response,
      };
    } catch (error: any) {
      if (error.message?.includes('permissions')) {
        throw new Error(
          'Integration lacks required comment capabilities. Please ensure your Notion integration has "Insert comments" capability enabled.'
        );
      }
      throw error;
    }
  },
});
