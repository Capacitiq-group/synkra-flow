import { notionAuth } from '../auth';
import {
  createAction,
  MarkdownVariant,
  Property,
} from '@activepieces/pieces-framework';
import { getNotionToken, notionCommon } from '../common';
import { Client } from '@notionhq/client';
import { notionFindDatabaseItemActionOutputSchema } from '../output-schemas';

export const findDatabaseItem = createAction({
  auth: notionAuth,
  name: 'notion-find-database-item',
  classification: 'SEARCH',
  displayName: 'Find Database Item',
  description: 'Find items in a database whose fields match exact values.',
  audience: 'human',
  aiMetadata: {
    description:
      'Queries a Notion database for items whose property values match the given filter fields (combined with AND). Use when an agent needs to look up existing records by field value before reading or updating them; requires the database_id and at least one filter field matching the database schema. Idempotent read-only lookup.',
    idempotent: true,
  },
  props: {
    database_id: notionCommon.database_id,
    filter_hint: Property.MarkDown({
      value:
        'Pick a database, then fill one or more of its fields. Items must match every value exactly.',
      variant: MarkdownVariant.INFO,
    }),
    filterDatabaseFields: notionCommon.filterDatabaseFields,
  },
  outputSchema: notionFindDatabaseItemActionOutputSchema,
  async run(context) {
    const databaseId = context.propsValue.database_id;
    const filterFields = context.propsValue.filterDatabaseFields;

    const notion = new Client({
      auth: getNotionToken(context.auth),
      notionVersion: '2022-02-22',
    });

    const { properties } = await notion.databases.retrieve({
      database_id: databaseId as string,
    });

    const filterArray = [];

    for (const fieldKey in filterFields) {
      const fieldValue = filterFields[fieldKey];
      const fieldType = properties[fieldKey].type;
      if (
        fieldValue === '' ||
        fieldValue === undefined ||
        fieldValue === null ||
        (Array.isArray(fieldValue) && fieldValue.length === 0)
      ) {
        continue;
      }
      switch (fieldType) {
        case 'number':
          filterArray.push({
            property: fieldKey,
            number: { equals: Number(fieldValue) },
          });
          break;
        case 'rich_text':
          filterArray.push({
            property: fieldKey,
            rich_text: { equals: fieldValue },
          });
          break;
        case 'email':
          filterArray.push({
            property: fieldKey,
            email: { equals: fieldValue },
          });
          break;
        case 'select':
          filterArray.push({
            property: fieldKey,
            select: { equals: fieldValue },
          });
          break;
        case 'phone_number':
          filterArray.push({
            property: fieldKey,
            phone_number: { equals: fieldValue },
          });
          break;
        case 'url':
          filterArray.push({ property: fieldKey, url: { equals: fieldValue } });
          break;
        case 'title':
          filterArray.push({
            property: fieldKey,
            title: { equals: fieldValue },
          });
          break;
        case 'date':
          filterArray.push({
            property: fieldKey,
            date: { equals: fieldValue },
          });
          break;
        case 'checkbox':
          filterArray.push({
            property: fieldKey,
            checkbox: { equals: Boolean(fieldValue) },
          });
          break;
        case 'status':
          filterArray.push({
            property: fieldKey,
            status: { equals: fieldValue },
          });
          break;
        case 'multi_select':
          for (const value of Array.isArray(fieldValue)
            ? fieldValue
            : [fieldValue]) {
            filterArray.push({
              property: fieldKey,
              multi_select: { contains: value },
            });
          }
          break;
        case 'people':
          filterArray.push({
            property: fieldKey,
            people: { contains: fieldValue },
          });
          break;
      }
    }

    const { results } = await notion.databases.query({
      database_id: databaseId as string,
      filter: {
        and: filterArray,
      },
    });

    return {
      success: results.length > 0,
      results,
    };
  },
});
