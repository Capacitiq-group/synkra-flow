import { createAction } from '@activepieces/pieces-framework';
import { Client } from '@notionhq/client';
import { notionAuth } from '../auth';
import { getNotionToken, notionCommon } from '../common';
import { archiveDatabaseItemActionOutputSchema } from '../output-schemas';

export const archiveDatabaseItem = createAction({
  auth: notionAuth,
  name: 'archive_database_item',
  classification: 'DESTRUCTIVE',
  displayName: 'Archive Database Item',
  description: 'Archive a database item. It can be restored later.',
  audience: 'human',
  aiMetadata: {
    description:
      'Soft-deletes a Notion database item by setting its archived flag, keeping it recoverable via Restore. Use when an agent must remove a record from active views without permanent deletion; requires the database_id and item id. Idempotent: archiving an already-archived item leaves it archived.',
    idempotent: true,
  },
  props: {
    database_id: notionCommon.database_id,
    database_item_id: notionCommon.database_item_id,
  },
  outputSchema: archiveDatabaseItemActionOutputSchema,
  async run(context) {
    const { database_id, database_item_id } = context.propsValue;

    if (!database_id) {
      throw new Error('Database selection is required');
    }

    if (!database_item_id) {
      throw new Error('Please select a database item to archive');
    }

    const notion = new Client({
      auth: getNotionToken(context.auth),
      notionVersion: '2022-02-22',
    });

    try {
      const response = await notion.pages.update({
        page_id: database_item_id,
        archived: true,
      });

      // Get the item title for better user feedback
      let itemTitle = 'Database item';
      let itemUrl = undefined;

      if ('properties' in response && response.properties) {
        const firstProperty = Object.values(response.properties)[0];
        if (
          firstProperty &&
          typeof firstProperty === 'object' &&
          'title' in firstProperty &&
          firstProperty.title
        ) {
          itemTitle =
            (firstProperty.title as any)[0]?.plain_text || 'Untitled item';
        }
      }

      if ('url' in response) {
        itemUrl = response.url;
      }

      return {
        success: true,
        message: `"${itemTitle}" has been archived successfully`,
        archivedItem: {
          id: response.id,
          title: itemTitle,
          url: itemUrl,
          archived_at: new Date().toISOString(),
        },
        // Include full response for advanced users
        fullResponse: response,
      };
    } catch (error: any) {
      if (
        error.message?.includes('permissions') ||
        error.message?.includes('unauthorized')
      ) {
        throw new Error(
          'Unable to archive item: Your Notion integration may lack edit permissions for this database. Please check your integration permissions in Notion.'
        );
      }

      if (error.message?.includes('not_found')) {
        throw new Error(
          'The selected item could not be found. It may have been deleted or moved to a different database.'
        );
      }

      // Re-throw with more context
      throw new Error(`Failed to archive database item: ${error.message}`);
    }
  },
});
